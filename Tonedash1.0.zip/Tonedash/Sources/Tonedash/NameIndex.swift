import Foundation

/// Maps game IDs to official names using libretro's database files (clrmamepro .dat format).
/// The .dat files are downloaded once per system and cached in Application Support.
actor NameIndex {
    static let shared = NameIndex()

    private var tables: [String: [String: String]] = [:]
    private var unavailable: Set<String> = []

    private static let base = "https://raw.githubusercontent.com/libretro/libretro-database/master/"

    static func normalize(_ s: String) -> String {
        s.uppercased().filter { $0.isLetter || $0.isNumber }
    }

    /// `available` is false when the database for this system couldn't be loaded (for example offline).
    func lookup(id: String, system: String) async -> (name: String?, available: Bool) {
        guard let table = await table(for: system) else { return (nil, false) }
        var keys = [Self.normalize(id)]
        if system.hasPrefix("Nintendo"), id.count >= 4 {
            keys.append(Self.normalize(String(id.prefix(4))))
        }
        for key in keys {
            if let name = table[key] { return (name, true) }
        }
        return (nil, true)
    }

    private func table(for system: String) async -> [String: String]? {
        if let cached = tables[system] { return cached }
        if unavailable.contains(system) { return nil }

        let fm = FileManager.default
        let support = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let dir = support.appendingPathComponent("Tonedash/db", isDirectory: true)
        let file = dir.appendingPathComponent("\(system).dat")

        var stale = true
        if let attrs = try? fm.attributesOfItem(atPath: file.path),
           let modified = attrs[.modificationDate] as? Date {
            stale = Date().timeIntervalSince(modified) > 30 * 86400
        }
        if stale, let data = await download(system: system) {
            try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
            try? data.write(to: file)
        }

        guard let data = try? Data(contentsOf: file) else {
            unavailable.insert(system)
            return nil
        }
        let parsed = Self.parse(data)
        tables[system] = parsed
        return parsed
    }

    private func download(system: String) async -> Data? {
        let paths = [
            "metadat/redump/\(system).dat",
            "dat/\(system).dat",
            "metadat/no-intro/\(system).dat"
        ]
        for path in paths {
            guard let encoded = path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
                  let url = URL(string: Self.base + encoded) else { continue }
            var request = URLRequest(url: url)
            request.timeoutInterval = 60
            if let (data, response) = try? await URLSession.shared.data(for: request),
               (response as? HTTPURLResponse)?.statusCode == 200,
               data.count > 2000 {
                return data
            }
        }
        return nil
    }

    /// Reads `name "..."` and `serial "..."` entries into [normalized serial: game name].
    static func parse(_ data: Data) -> [String: String] {
        let text = String(data: data, encoding: .utf8) ?? String(decoding: data, as: UTF8.self)
        var table: [String: String] = [:]
        var current: String?

        for rawLine in text.split(whereSeparator: \.isNewline) {
            let line = rawLine.trimmingCharacters(in: .whitespaces)
            if line.hasPrefix("game (") {
                current = nil
                continue
            }
            if line.hasPrefix("name \""), let name = quoted(line, key: "name") {
                current = name
                continue
            }
            if let name = current, let serial = quoted(line, key: "serial") {
                for part in serial.split(whereSeparator: { ", ;/".contains($0) }) {
                    let key = normalize(String(part))
                    if !key.isEmpty, table[key] == nil { table[key] = name }
                }
            }
        }
        return table
    }

    private static func quoted(_ line: String, key: String) -> String? {
        guard let range = line.range(of: key + " \"") else { return nil }
        let rest = line[range.upperBound...]
        guard let end = rest.firstIndex(of: "\"") else { return nil }
        return String(rest[..<end])
    }
}
