import Foundation
import SwiftUI

struct Library: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var folderPath: String
    var emulatorPath: String      // a .app bundle or a plain executable
    var extraArgs: String         // arguments placed before the game path
    var libretroSystem: String    // fallback cover system when a game can't be auto-identified
}

/// What was read from the disc itself.
struct DiscInfo: Codable, Hashable {
    var id: String                // e.g. SLUS-20312, ULUS10041, GALE01
    var system: String            // libretro system name, e.g. "Sony - PlayStation 2"
    var title: String?            // title embedded in the disc (GameCube/Wii header, PSP PARAM.SFO)
    var name: String?             // canonical name from the database lookup
    var nameChecked: Bool         // true once the database lookup has actually run
}

struct CacheEntry: Codable {
    var size: UInt64
    var mtime: Double
    var info: DiscInfo?
}

struct Stamp {
    var size: UInt64
    var mtime: Double
}

struct Game: Identifiable, Hashable {
    let id: String                // file path
    let title: String             // file name without extension
    let path: String
    let library: Library
    var info: DiscInfo? = nil

    /// Best available title, without region/disc tags like "(USA)" or "[!]".
    var displayTitle: String {
        let base = info?.name ?? info?.title ?? title
        let cleaned = base
            .replacingOccurrences(of: #"\s*[\(\[][^\)\]]*[\)\]]"#, with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespaces)
        return cleaned.isEmpty ? base : cleaned
    }

    /// Small line shown under the title: system and game ID, or the library name if unidentified.
    var subtitleTag: String {
        guard let info else { return library.name }
        let system = info.system
            .replacingOccurrences(of: "Sony - ", with: "")
            .replacingOccurrences(of: "Nintendo - ", with: "")
        return "\(system)  •  \(info.id)"
    }
}

struct Preset: Identifiable {
    let id = UUID()
    let name: String
    let system: String
    let args: String
    let appName: String

    func makeLibrary() -> Library {
        let guess = "/Applications/\(appName).app"
        let exists = !appName.isEmpty && FileManager.default.fileExists(atPath: guess)
        return Library(name: name, folderPath: "", emulatorPath: exists ? guess : "",
                       extraArgs: args, libretroSystem: system)
    }

    // Starting points only; check your emulator's command-line options and edit as needed.
    static let all: [Preset] = [
        Preset(name: "PlayStation 2 (PCSX2)", system: "Sony - PlayStation 2", args: "-batch -fullscreen --", appName: "PCSX2"),
        Preset(name: "PlayStation (DuckStation)", system: "Sony - PlayStation", args: "-batch -fullscreen --", appName: "DuckStation"),
        Preset(name: "GameCube (Dolphin)", system: "Nintendo - GameCube", args: "-b -e", appName: "Dolphin"),
        Preset(name: "Wii (Dolphin)", system: "Nintendo - Wii", args: "-b -e", appName: "Dolphin"),
        Preset(name: "PSP (PPSSPP)", system: "Sony - PlayStation Portable", args: "", appName: "PPSSPP"),
        Preset(name: "Dreamcast (Flycast)", system: "Sega - Dreamcast", args: "", appName: "Flycast"),
        Preset(name: "NES", system: "Nintendo - Nintendo Entertainment System", args: "", appName: "Mesen"),
        Preset(name: "SNES", system: "Nintendo - Super Nintendo Entertainment System", args: "", appName: "Snes9x"),
        Preset(name: "Nintendo 64", system: "Nintendo - Nintendo 64", args: "", appName: ""),
        Preset(name: "Game Boy / Color", system: "Nintendo - Game Boy Color", args: "", appName: "mGBA"),
        Preset(name: "Game Boy Advance", system: "Nintendo - Game Boy Advance", args: "", appName: "mGBA"),
        Preset(name: "Genesis / Mega Drive", system: "Sega - Mega Drive - Genesis", args: "", appName: ""),
        Preset(name: "Nintendo DS", system: "Nintendo - Nintendo DS", args: "", appName: "melonDS"),
        Preset(name: "Nintendo 3DS", system: "Nintendo - Nintendo 3DS", args: "", appName: ""),
        Preset(name: "Custom", system: "", args: "", appName: "")
    ]
}
