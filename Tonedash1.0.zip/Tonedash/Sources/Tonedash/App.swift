import SwiftUI
import AppKit

@main
struct TonedashApp: App {
    @StateObject private var store = LibraryStore()
    @StateObject private var pad = ControllerManager()

    var body: some Scene {
        WindowGroup("Tonedash") {
            ContentView()
                .environmentObject(store)
                .environmentObject(pad)
                .frame(minWidth: 960, minHeight: 540)
                .preferredColorScheme(.dark)
                .onAppear {
                    // Start in fullscreen.
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
                        if let window = NSApp.windows.first, !window.styleMask.contains(.fullScreen) {
                            window.toggleFullScreen(nil)
                        }
                    }
                }
        }
        .windowStyle(.hiddenTitleBar)
    }
}
