import SwiftUI
import AppKit

func choosePath(folder: Bool, _ done: (String) -> Void) {
    let panel = NSOpenPanel()
    panel.canChooseDirectories = folder
    panel.canChooseFiles = !folder
    panel.allowsMultipleSelection = false
    if !folder { panel.directoryURL = URL(fileURLWithPath: "/Applications") }
    if panel.runModal() == .OK, let url = panel.url {
        done(url.path)
    }
}

struct SettingsView: View {
    @EnvironmentObject var store: LibraryStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Libraries").font(.title2.bold())
                Spacer()
                Menu("Add Library") {
                    ForEach(Preset.all) { preset in
                        Button(preset.name) { store.libraries.append(preset.makeLibrary()) }
                    }
                }
                .fixedSize()
                Button("Done") { dismiss() }
                    .keyboardShortcut(.defaultAction)
            }

            Text("Each library is a folder of games plus the emulator that runs them. The game's path is added after the arguments.")
                .font(.caption)
                .foregroundColor(.secondary)

            ScrollView {
                VStack(spacing: 12) {
                    ForEach($store.libraries) { $lib in
                        LibraryEditor(lib: $lib) {
                            let id = lib.id
                            store.libraries.removeAll { $0.id == id }
                        }
                    }
                }
            }

            Divider()

            HStack {
                Button("Change Background…") { store.chooseBackground() }
                if store.backgroundImage != nil {
                    Button("Reset to Default") { store.resetBackground() }
                }
                Spacer()
            }
        }
        .padding(20)
        .frame(width: 640, height: 520)
    }
}

struct LibraryEditor: View {
    @Binding var lib: Library
    var onDelete: () -> Void

    var body: some View {
        GroupBox {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    TextField("Name", text: $lib.name)
                    Button(role: .destructive, action: onDelete) { Image(systemName: "trash") }
                }
                pathRow("Games folder", $lib.folderPath, folder: true)
                pathRow("Emulator", $lib.emulatorPath, folder: false)
                TextField("Emulator arguments (e.g. -batch -fullscreen --)", text: $lib.extraArgs)
                TextField("Fallback cover system, used only if a game can't be auto-identified (e.g. Sony - PlayStation 2)", text: $lib.libretroSystem)
            }
            .padding(4)
        }
    }

    private func pathRow(_ label: String, _ binding: Binding<String>, folder: Bool) -> some View {
        HStack {
            TextField(label, text: binding)
            Button("Choose…") {
                choosePath(folder: folder) { binding.wrappedValue = $0 }
            }
        }
    }
}
