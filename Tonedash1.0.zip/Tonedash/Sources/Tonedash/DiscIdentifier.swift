import Foundation

/// Reads the game ID straight out of a disc image.
///   GameCube / Wii : 6-character ID in the disc header (plus an embedded title)
///   PS1 / PS2      : serial from SYSTEM.CNF inside the ISO9660 file system
///   PSP            : DISC_ID and TITLE from PSP_GAME/PARAM.SFO
/// Compressed formats (.chd, .cso, .rvz) are not read yet; those games fall back to their file name.
enum DiscIdentifier {
    static let sysPSX = "Sony - PlayStation"
    static let sysPS2 = "Sony - PlayStation 2"
    static let sysPSP = "Sony - PlayStation Portable"
    static let sysGC = "Nintendo - GameCube"
    static let sysWii = "Nintendo - Wii"

    static func identify(path: String) -> DiscInfo? {
        let url = URL(fileURLWithPath: path)
        let ext = url.pathExtension.lowercased()

        switch ext {
        case "wbfs":
            guard let handle = try? FileHandle(forReadingFrom: url) else { return nil }
            defer { try? handle.close() }
            guard let head = readBytes(handle, at: 0x200, count: 0x60) else { return nil }
            return nintendoInfo(head)

        case "iso", "gcm", "img", "bin", "cue":
            let target: URL? = (ext == "cue") ? binFile(forCue: url) : url
            guard let target, let handle = try? FileHandle(forReadingFrom: target) else { return nil }
            defer { try? handle.close() }

            if let head = readBytes(handle, at: 0, count: 0x60), let info = nintendoInfo(head) {
                return info
            }
            guard let disc = DiscImage(handle: handle) else { return nil }
            return pspInfo(disc) ?? playStationInfo(disc)

        default:
            return nil
        }
    }

    // MARK: Nintendo

    static func nintendoInfo(_ b: [UInt8]) -> DiscInfo? {
        guard b.count >= 0x60 else { return nil }
        let isWii = be32(b, 0x18) == 0x5D1C9EA3
        let isGC = be32(b, 0x1C) == 0xC2339F3D
        guard isWii || isGC else { return nil }

        let idBytes = Array(b[0..<6])
        guard idBytes.allSatisfy({ $0 >= 0x30 && $0 < 0x7F }) else { return nil }
        let id = String(decoding: idBytes, as: UTF8.self)

        let titleBytes = b[0x20..<0x60].prefix { $0 != 0 }
        let title = String(decoding: titleBytes, as: UTF8.self).trimmingCharacters(in: .whitespaces)

        return DiscInfo(id: id, system: isWii ? sysWii : sysGC,
                        title: title.isEmpty ? nil : title, name: nil, nameChecked: false)
    }

    // MARK: PSP

    static func pspInfo(_ disc: DiscImage) -> DiscInfo? {
        guard let file = disc.lookup(["PSP_GAME", "PARAM.SFO"]), file.size < 65536,
              let bytes = disc.read(lba: file.lba, byteCount: Int(file.size)) else { return nil }
        let sfo = parseSFO(bytes)
        guard let id = sfo["DISC_ID"], !id.isEmpty else { return nil }
        let title = sfo["TITLE"]?.trimmingCharacters(in: .whitespacesAndNewlines)
        return DiscInfo(id: id, system: sysPSP,
                        title: (title?.isEmpty ?? true) ? nil : title, name: nil, nameChecked: false)
    }

    static func parseSFO(_ b: [UInt8]) -> [String: String] {
        guard b.count > 20, b[0] == 0, b[1] == 0x50, b[2] == 0x53, b[3] == 0x46 else { return [:] }
        let keyTable = Int(le32(b, 8))
        let dataTable = Int(le32(b, 12))
        let count = Int(le32(b, 16))
        var out: [String: String] = [:]

        for i in 0..<min(count, 64) {
            let e = 20 + i * 16
            guard e + 16 <= b.count else { break }
            let keyOffset = Int(le16(b, e))
            let format = le16(b, e + 2)
            let length = Int(le32(b, e + 4))
            let dataOffset = Int(le32(b, e + 12))
            guard format == 0x0204 else { continue }          // UTF-8 string

            let keyStart = keyTable + keyOffset
            let valueStart = dataTable + dataOffset
            guard keyStart < b.count, valueStart + length <= b.count else { continue }

            let key = String(decoding: b[keyStart...].prefix { $0 != 0 }, as: UTF8.self)
            let value = String(decoding: b[valueStart..<(valueStart + length)].prefix { $0 != 0 }, as: UTF8.self)
            out[key] = value
        }
        return out
    }

    // MARK: PS1 / PS2

    static func playStationInfo(_ disc: DiscImage) -> DiscInfo? {
        guard let file = disc.lookup(["SYSTEM.CNF"]), file.size < 8192,
              let bytes = disc.read(lba: file.lba, byteCount: Int(file.size)) else { return nil }
        let text = String(decoding: bytes, as: UTF8.self).uppercased()
        guard let serial = serial(in: text) else { return nil }
        let isPS2 = text.contains("BOOT2")
        return DiscInfo(id: serial, system: isPS2 ? sysPS2 : sysPSX, title: nil, name: nil, nameChecked: false)
    }

    /// "BOOT2 = cdrom0:\SLUS_203.12;1" -> "SLUS-20312"
    static func serial(in text: String) -> String? {
        for line in text.split(whereSeparator: \.isNewline) where line.contains("BOOT") {
            let s = String(line)
            if let range = s.range(of: #"([A-Z]{4})[_-]?(\d{3})\.?(\d{2})"#, options: .regularExpression) {
                let compact = String(s[range]).filter { $0.isLetter || $0.isNumber }
                return String(compact.prefix(4)) + "-" + String(compact.dropFirst(4))
            }
        }
        return nil
    }

    // MARK: Cue sheets

    static func binFile(forCue cue: URL) -> URL? {
        let text = (try? String(contentsOf: cue, encoding: .utf8))
            ?? (try? String(contentsOf: cue, encoding: .isoLatin1))
        guard let text,
              let regex = try? NSRegularExpression(pattern: #"FILE\s+"([^"]+)""#, options: .caseInsensitive),
              let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)),
              let range = Range(match.range(at: 1), in: text) else { return nil }
        return cue.deletingLastPathComponent().appendingPathComponent(String(text[range]))
    }

    // MARK: Byte helpers

    static func readBytes(_ handle: FileHandle, at offset: UInt64, count: Int) -> [UInt8]? {
        do {
            try handle.seek(toOffset: offset)
            guard let data = try handle.read(upToCount: count), data.count == count else { return nil }
            return [UInt8](data)
        } catch {
            return nil
        }
    }

    static func le16(_ b: [UInt8], _ o: Int) -> UInt16 {
        UInt16(b[o]) | (UInt16(b[o + 1]) << 8)
    }

    static func le32(_ b: [UInt8], _ o: Int) -> UInt32 {
        UInt32(b[o]) | (UInt32(b[o + 1]) << 8) | (UInt32(b[o + 2]) << 16) | (UInt32(b[o + 3]) << 24)
    }

    static func be32(_ b: [UInt8], _ o: Int) -> UInt32 {
        (UInt32(b[o]) << 24) | (UInt32(b[o + 1]) << 16) | (UInt32(b[o + 2]) << 8) | UInt32(b[o + 3])
    }
}

/// Minimal ISO9660 reader for .iso files and raw .bin images.
struct DiscImage {
    let handle: FileHandle
    let sectorSize: UInt64
    let dataOffset: UInt64

    init?(handle: FileHandle) {
        self.handle = handle
        // Cooked ISO (2048), raw mode 1 (2352, +16) or raw mode 2 (2352, +24).
        let layouts: [(UInt64, UInt64)] = [(2048, 0), (2352, 16), (2352, 24)]
        let signature: [UInt8] = [1, 0x43, 0x44, 0x30, 0x30, 0x31]   // 01 "CD001"
        for (size, offset) in layouts {
            if let bytes = DiscIdentifier.readBytes(handle, at: 16 * size + offset, count: 6), bytes == signature {
                self.sectorSize = size
                self.dataOffset = offset
                return
            }
        }
        return nil
    }

    func read(lba: UInt32, byteCount: Int) -> [UInt8]? {
        guard byteCount >= 0, byteCount <= 1_048_576 else { return nil }
        var out = [UInt8]()
        out.reserveCapacity(byteCount)
        var sector = UInt64(lba)
        while out.count < byteCount {
            guard let chunk = DiscIdentifier.readBytes(handle, at: sector * sectorSize + dataOffset, count: 2048) else {
                return nil
            }
            out.append(contentsOf: chunk)
            sector += 1
        }
        return Array(out.prefix(byteCount))
    }

    /// Finds a file by path components, e.g. ["PSP_GAME", "PARAM.SFO"].
    func lookup(_ components: [String]) -> (lba: UInt32, size: UInt32)? {
        guard let pvd = read(lba: 16, byteCount: 2048) else { return nil }
        var lba = DiscIdentifier.le32(pvd, 156 + 2)
        var size = DiscIdentifier.le32(pvd, 156 + 10)

        for (index, component) in components.enumerated() {
            guard let dir = read(lba: lba, byteCount: Int(size)) else { return nil }
            var pos = 0
            var found: (lba: UInt32, size: UInt32, isDir: Bool)?

            while pos + 33 <= dir.count {
                let length = Int(dir[pos])
                if length == 0 {                                   // padding to the next sector
                    pos = (pos / 2048 + 1) * 2048
                    continue
                }
                let nameLength = Int(dir[pos + 32])
                guard pos + 33 + nameLength <= dir.count else { break }

                var name = String(decoding: dir[(pos + 33)..<(pos + 33 + nameLength)], as: UTF8.self)
                if let semicolon = name.firstIndex(of: ";") { name = String(name[..<semicolon]) }

                if name.caseInsensitiveCompare(component) == .orderedSame {
                    found = (DiscIdentifier.le32(dir, pos + 2),
                             DiscIdentifier.le32(dir, pos + 10),
                             (dir[pos + 25] & 0x02) != 0)
                    break
                }
                pos += length
            }

            guard let entry = found else { return nil }
            if index == components.count - 1 { return (entry.lba, entry.size) }
            guard entry.isDir else { return nil }
            lba = entry.lba
            size = entry.size
        }
        return nil
    }
}
