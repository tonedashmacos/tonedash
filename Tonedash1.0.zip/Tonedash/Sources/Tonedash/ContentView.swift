import SwiftUI
import AppKit

// MARK: - Root

struct ContentView: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var pad: ControllerManager
    @State private var keyMonitor: Any?

    var body: some View {
        ZStack {
            Backdrop()

            if store.libraries.isEmpty {
                EmptyState()
            } else if store.visibleGames.isEmpty {
                Text("No games found in this library")
                    .font(.title2)
                    .foregroundColor(Color.white.opacity(0.7))
            } else {
                Carousel()
            }

            VStack {
                TopBar()
                Spacer()
                if let status = store.identifyStatus {
                    Text(status)
                        .font(.system(size: 13))
                        .foregroundColor(Color.white.opacity(0.55))
                        .padding(.bottom, 6)
                }
                BottomBar()
            }

            if let game = store.coverMenuGame {
                CoverMenu(game: game)
                    .transition(.opacity)
            }

            if let title = store.launchingTitle {
                LaunchOverlay(title: title)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: store.launchingTitle)
        .animation(.easeInOut(duration: 0.15), value: store.coverMenuGame != nil)
        .ignoresSafeArea()
        .sheet(isPresented: $store.showSettings, onDismiss: { store.rescan() }) {
            SettingsView().environmentObject(store)
        }
        .alert("Launcher", isPresented: Binding(
            get: { store.lastError != nil },
            set: { if !$0 { store.lastError = nil } }
        )) {
            Button("OK") {}
        } message: {
            Text(store.lastError ?? "")
        }
        .onAppear { wireInput() }
    }

    private func wireInput() {
        pad.onMove = { dx, dy in
            guard !store.paused else { return }
            if store.coverMenuGame != nil {
                if dy != 0 { store.moveCoverMenu(dy) }
                return
            }
            if dy != 0 { store.cycleLibrary(dy) } else { store.move(dx: dx) }
        }
        pad.onConfirm = {
            guard !store.paused else { return }
            if store.coverMenuGame != nil { store.activateCoverMenu() } else { store.launchSelected() }
        }
        pad.onBack = { if store.coverMenuGame != nil { store.closeCoverMenu() } }
        pad.onCover = { store.openCoverMenu() }
        pad.onShoulder = { step in if !store.inputLocked { store.cycleLibrary(step) } }
        pad.onJump = { step in if !store.inputLocked { store.move(dx: step * 10) } }
        pad.onRefresh = { if !store.inputLocked { store.rescan() } }
        pad.onSettings = { if !store.inputLocked { store.showSettings = true } }

        guard keyMonitor == nil else { return }
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { (event: NSEvent) -> NSEvent? in
            if store.paused { return event }

            if store.coverMenuGame != nil {
                switch event.keyCode {
                case 126: store.moveCoverMenu(-1)                    // up
                case 125: store.moveCoverMenu(1)                     // down
                case 36, 76: store.activateCoverMenu()               // return
                case 53: store.closeCoverMenu()                      // esc
                default: break
                }
                return nil
            }

            switch event.keyCode {
            case 123: store.move(dx: -1); return nil                 // left
            case 124: store.move(dx: 1); return nil                  // right
            case 126: store.cycleLibrary(-1); return nil             // up
            case 125: store.cycleLibrary(1); return nil              // down
            case 36, 76: store.launchSelected(); return nil          // return
            default: break
            }
            guard event.modifierFlags.intersection([.command, .control, .option]).isEmpty else { return event }
            switch event.charactersIgnoringModifiers {
            case "s": store.showSettings = true; return nil
            case "r": store.rescan(); return nil
            case "c": store.openCoverMenu(); return nil
            case "f": NSApp.keyWindow?.toggleFullScreen(nil); return nil
            default: return event
            }
        }
    }
}

// MARK: - Background

struct Backdrop: View {
    @EnvironmentObject var store: LibraryStore

    var body: some View {
        ZStack {
            if let image = store.backgroundImage {
                GeometryReader { geo in
                    Image(nsImage: image)
                        .resizable()
                        .scaledToFill()
                        .frame(width: geo.size.width, height: geo.size.height)
                        .clipped()
                }
                // Keeps the title, tabs and hints readable over any picture.
                LinearGradient(colors: [Color.black.opacity(0.45), Color.black.opacity(0.15), Color.black.opacity(0.55)],
                               startPoint: .top, endPoint: .bottom)
            } else {
                defaultBackdrop
            }
        }
        .ignoresSafeArea()
    }

    private var defaultBackdrop: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.04, green: 0.06, blue: 0.22),
                         Color(red: 0.09, green: 0.05, blue: 0.26),
                         Color(red: 0.03, green: 0.03, blue: 0.10)],
                startPoint: .top, endPoint: .bottom)
            RadialGradient(
                colors: [Color(red: 0.95, green: 0.40, blue: 0.70).opacity(0.38), Color.clear],
                center: .bottomLeading, startRadius: 0, endRadius: 800)
            RadialGradient(
                colors: [Color(red: 0.40, green: 0.50, blue: 1.0).opacity(0.38), Color.clear],
                center: .bottomTrailing, startRadius: 0, endRadius: 900)
            RadialGradient(
                colors: [Color(red: 0.30, green: 0.35, blue: 0.85).opacity(0.25), Color.clear],
                center: .top, startRadius: 0, endRadius: 700)
        }
    }
}

// MARK: - Carousel

struct Carousel: View {
    @EnvironmentObject var store: LibraryStore

    var body: some View {
        GeometryReader { geo in
            let list = store.visibleGames
            let sel = min(store.selectedIndex, max(list.count - 1, 0))
            let W = geo.size.width
            let H = geo.size.height

            let ratio: CGFloat = 0.74
            let baseH = H * 0.33
            let selH = H * 0.46
            let baseW = baseH * ratio
            let selW = selH * ratio
            let gap: CGFloat = 30
            let bottomY = H * 0.46 + selH / 2

            let indices: [Int] = list.isEmpty ? [] : Array(max(0, sel - 6)...min(list.count - 1, sel + 6))

            ZStack {
                ForEach(indices, id: \.self) { i in
                    let d = i - sel
                    let isSel = d == 0
                    let h = isSel ? selH : baseH
                    let w = isSel ? selW : baseW
                    let sign: CGFloat = d > 0 ? 1 : -1
                    let dist = CGFloat(abs(d))
                    let xOff: CGFloat = isSel ? 0 : sign * (selW / 2 + gap + baseW / 2 + (dist - 1) * (baseW + gap))

                    CoverTile(game: list[i], selected: isSel, width: w, height: h, revision: store.coverRevision)
                        .opacity(isSel ? 1 : max(0.3, 0.85 - 0.12 * Double(abs(d))))
                        .position(x: W / 2 + xOff, y: bottomY - h / 2)
                        .zIndex(isSel ? 1 : 0)
                        .onTapGesture {
                            if isSel { store.launch(list[i]) } else { store.selectedGameID = list[i].id }
                        }
                }
            }
            .animation(.spring(response: 0.38, dampingFraction: 0.82), value: sel)

            if !list.isEmpty {
                VStack(spacing: 6) {
                    Text(list[sel].displayTitle)
                        .font(.system(size: max(22, H * 0.04), weight: .semibold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                    Text("\(list[sel].subtitleTag)   •   \(sel + 1) of \(list.count)")
                        .font(.system(size: max(14, H * 0.02)))
                        .foregroundColor(Color.white.opacity(0.6))
                }
                .frame(width: W)
                .position(x: W / 2, y: H * 0.86)
                .id(list[sel].id)
                .transition(.opacity)
            }
        }
    }
}

struct CoverTile: View {
    let game: Game
    let selected: Bool
    let width: CGFloat
    let height: CGFloat
    let revision: Int
    @State private var image: NSImage?

    private struct LoadKey: Hashable {
        let game: Game
        let revision: Int
    }

    var body: some View {
        let refH = height * 0.28
        cover
            .frame(width: width, height: height, alignment: .bottom)
            .overlay(alignment: .bottom) {
                if let image {
                    reflection(image, refH)
                        .offset(y: refH + 3)
                }
            }
            .task(id: LoadKey(game: game, revision: revision)) {
                image = await CoverLoader.load(for: game)
            }
    }

    @ViewBuilder
    private var cover: some View {
        let border = selected ? Color(red: 0.55, green: 0.95, blue: 0.30) : Color.white.opacity(0.18)
        let glow = selected ? Color(red: 0.55, green: 0.95, blue: 0.30).opacity(0.55) : Color.black.opacity(0.5)
        if let image {
            Image(nsImage: image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .overlay(Rectangle().stroke(border, lineWidth: selected ? 3 : 1))
                .shadow(color: glow, radius: selected ? 20 : 8)
        } else {
            RoundedRectangle(cornerRadius: 6)
                .fill(LinearGradient(colors: [Color.white.opacity(0.18), Color.white.opacity(0.06)],
                                     startPoint: .top, endPoint: .bottom))
                .frame(width: width, height: height)
                .overlay(
                    VStack(spacing: 10) {
                        Image(systemName: "opticaldisc")
                            .font(.system(size: width * 0.25))
                        Text(game.displayTitle)
                            .font(.system(size: max(11, width * 0.08), weight: .semibold))
                            .multilineTextAlignment(.center)
                            .lineLimit(4)
                            .padding(.horizontal, 10)
                    }
                    .foregroundColor(Color.white.opacity(0.75))
                )
                .overlay(RoundedRectangle(cornerRadius: 6).stroke(border, lineWidth: selected ? 3 : 1))
                .shadow(color: glow, radius: selected ? 20 : 8)
        }
    }

    private func reflection(_ img: NSImage, _ refH: CGFloat) -> some View {
        Image(nsImage: img)
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: width, height: height, alignment: .bottom)
            .scaleEffect(x: 1, y: -1)
            .frame(width: width, height: refH, alignment: .top)
            .clipped()
            .mask(
                LinearGradient(colors: [Color.white.opacity(0.35), Color.clear],
                               startPoint: .top, endPoint: .bottom)
            )
    }
}

// MARK: - Top and bottom bars

struct TopBar: View {
    @EnvironmentObject var store: LibraryStore
    @EnvironmentObject var pad: ControllerManager

    private var tabs: [(id: UUID, name: String)] {
        [(LibraryStore.allID, "All Games")] + store.libraries.map { ($0.id, $0.name) }
    }

    var body: some View {
        HStack(spacing: 26) {
            if pad.connectedName != nil { shoulderBadge("LB") }
            ForEach(tabs, id: \.id) { tab in
                let active = (store.selectedLibraryID ?? LibraryStore.allID) == tab.id
                Text(tab.name)
                    .font(.system(size: 22, weight: active ? .bold : .regular))
                    .foregroundColor(active ? Color.white : Color.white.opacity(0.5))
                    .padding(.bottom, 6)
                    .overlay(alignment: .bottom) {
                        if active { Rectangle().fill(Color.white).frame(height: 2) }
                    }
                    .onTapGesture { store.selectedLibraryID = tab.id }
            }
            if pad.connectedName != nil { shoulderBadge("RB") }

            Spacer()

            if pad.connectedName != nil {
                Image(systemName: "gamecontroller.fill")
                    .foregroundColor(Color(red: 0.55, green: 0.95, blue: 0.30))
            }
            TimelineView(.periodic(from: .now, by: 20)) { context in
                Text(context.date, format: .dateTime.hour().minute())
                    .font(.system(size: 20, weight: .medium))
                    .foregroundColor(Color.white.opacity(0.85))
            }
            Button { store.showSettings = true } label: {
                Image(systemName: "gearshape.fill").font(.system(size: 20))
            }
            .buttonStyle(.plain)
            .foregroundColor(Color.white.opacity(0.85))
        }
        .padding(.horizontal, 48)
        .padding(.top, 36)
    }

    private func shoulderBadge(_ text: String) -> some View {
        Text(text)
            .font(.system(size: 12, weight: .bold))
            .foregroundColor(Color.white.opacity(0.8))
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .overlay(RoundedRectangle(cornerRadius: 5).stroke(Color.white.opacity(0.5), lineWidth: 1))
    }
}

struct BottomBar: View {
    @EnvironmentObject var store: LibraryStore

    var body: some View {
        HStack(spacing: 30) {
            Spacer()
            HStack(spacing: 8) {
                Hint(symbol: "◀", color: Color.white.opacity(0.85), label: nil) { store.move(dx: -1) }
                Hint(symbol: "▶", color: Color.white.opacity(0.85), label: "Browse") { store.move(dx: 1) }
            }
            Hint(symbol: "A", color: Color(red: 0.45, green: 0.85, blue: 0.25), label: "Play") { store.launchSelected() }
            Hint(symbol: "X", color: Color(red: 0.35, green: 0.62, blue: 1.0), label: "Cover") { store.openCoverMenu() }
            Hint(symbol: "Y", color: Color(red: 1.0, green: 0.80, blue: 0.20), label: "Rescan") { store.rescan() }
            Hint(symbol: "☰", color: Color.white.opacity(0.85), label: "Libraries") { store.showSettings = true }
            Spacer()
        }
        .padding(.bottom, 28)
    }
}

/// A button hint. Clickable when given an action (ignored while a dialog or the cover menu is open).
struct Hint: View {
    @EnvironmentObject var store: LibraryStore
    let symbol: String
    let color: Color
    let label: String?
    var action: (() -> Void)? = nil
    @State private var hovering = false

    var body: some View {
        if let action {
            Button {
                if !store.inputLocked { action() }
            } label: { content }
            .buttonStyle(.plain)
            .scaleEffect(hovering ? 1.08 : 1)
            .opacity(hovering ? 1 : 0.92)
            .animation(.easeOut(duration: 0.12), value: hovering)
            .onHover { hovering = $0 }
        } else {
            content
        }
    }

    private var content: some View {
        HStack(spacing: 8) {
            Text(symbol)
                .font(.system(size: 13, weight: .bold))
                .foregroundColor(.black)
                .frame(minWidth: 26, minHeight: 26)
                .padding(.horizontal, symbol.count > 1 ? 4 : 0)
                .background(Capsule().fill(color))
            if let label {
                Text(label)
                    .font(.system(size: 16))
                    .foregroundColor(Color.white.opacity(0.85))
            }
        }
        .contentShape(Rectangle())
    }
}

// MARK: - Overlays

struct CoverMenu: View {
    @EnvironmentObject var store: LibraryStore
    let game: Game

    var body: some View {
        ZStack {
            Color.black.opacity(0.6)
                .ignoresSafeArea()
                .onTapGesture { store.closeCoverMenu() }

            VStack(spacing: 6) {
                Text(game.displayTitle)
                    .font(.system(size: 22, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                    .padding(.bottom, 12)

                let options = store.coverMenuOptions
                ForEach(Array(options.enumerated()), id: \.offset) { index, option in
                    let focused = index == store.coverMenuIndex
                    Text(option.title)
                        .font(.system(size: 18, weight: focused ? .semibold : .regular))
                        .foregroundColor(focused ? .black : Color.white.opacity(0.85))
                        .frame(width: 300, height: 44)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(focused ? Color(red: 0.55, green: 0.95, blue: 0.30)
                                              : Color.white.opacity(0.10))
                        )
                        .contentShape(Rectangle())
                        .onTapGesture {
                            store.coverMenuIndex = index
                            store.chooseCoverOption(option)
                        }
                }

                HStack(spacing: 22) {
                    Hint(symbol: "A", color: Color(red: 0.45, green: 0.85, blue: 0.25), label: "Select")
                    Hint(symbol: "B", color: Color(red: 1.0, green: 0.40, blue: 0.40), label: "Back")
                }
                .padding(.top, 16)
            }
            .padding(32)
            .background(
                RoundedRectangle(cornerRadius: 18)
                    .fill(Color(red: 0.07, green: 0.08, blue: 0.20).opacity(0.96))
                    .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.15), lineWidth: 1))
            )
        }
    }
}

struct EmptyState: View {
    @EnvironmentObject var store: LibraryStore

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "opticaldisc")
                .font(.system(size: 64))
                .foregroundColor(Color.white.opacity(0.6))
            Text("Welcome")
                .font(.system(size: 34, weight: .bold))
                .foregroundColor(.white)
            Text("Add a library: a folder of games and the emulator that runs them.")
                .foregroundColor(Color.white.opacity(0.7))
            Button("Add a Library") { store.showSettings = true }
                .controlSize(.large)
        }
    }
}

struct LaunchOverlay: View {
    let title: String

    var body: some View {
        ZStack {
            Color.black.opacity(0.7)
            VStack(spacing: 14) {
                ProgressView().controlSize(.large)
                Text("Launching")
                    .font(.system(size: 16))
                    .foregroundColor(Color.white.opacity(0.6))
                Text(title)
                    .font(.system(size: 30, weight: .semibold))
                    .foregroundColor(.white)
            }
        }
        .ignoresSafeArea()
    }
}
