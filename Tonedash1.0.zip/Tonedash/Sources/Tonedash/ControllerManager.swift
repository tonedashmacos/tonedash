import Foundation
import GameController
import AppKit

/// Maps any connected gamepad to launcher actions:
/// D-pad / stick left-right = browse, up-down or LB/RB = switch library, A = play,
/// X (Square) = cover menu, B = back, LT/RT = jump 10 games, Y = rescan, Menu = libraries.
final class ControllerManager: ObservableObject {
    @Published var connectedName: String?

    var onMove: ((Int, Int) -> Void)?
    var onConfirm: (() -> Void)?
    var onBack: (() -> Void)?
    var onCover: (() -> Void)?
    var onShoulder: ((Int) -> Void)?
    var onJump: ((Int) -> Void)?
    var onRefresh: (() -> Void)?
    var onSettings: (() -> Void)?

    private struct Dir: Equatable {
        var x = 0
        var y = 0
        var isNeutral: Bool { x == 0 && y == 0 }
    }

    // The D-pad and the stick are tracked separately so releasing one can't cancel the other,
    // and so a controller that reports both for the same press only counts as one movement.
    private var dpad = Dir()
    private var stick = Dir()
    private var active = Dir()
    private var nextRepeat: TimeInterval = 0
    private var timer: Timer?

    /// A tap moves exactly one game. Holding waits this long, then repeats.
    private let initialDelay: TimeInterval = 0.40
    private let repeatInterval: TimeInterval = 0.12

    init() {
        // Keep receiving input if the window loses focus; actions are ignored unless the app is active.
        GCController.shouldMonitorBackgroundEvents = true

        NotificationCenter.default.addObserver(forName: .GCControllerDidConnect, object: nil, queue: .main) { [weak self] note in
            if let c = note.object as? GCController { self?.attach(c) }
        }
        NotificationCenter.default.addObserver(forName: .GCControllerDidDisconnect, object: nil, queue: .main) { [weak self] _ in
            guard let self else { return }
            self.connectedName = GCController.controllers().first?.vendorName
            self.dpad = Dir()
            self.stick = Dir()
            self.refresh()
        }
        GCController.startWirelessControllerDiscovery {}
        GCController.controllers().forEach { attach($0) }
    }

    private func attach(_ controller: GCController) {
        connectedName = controller.vendorName ?? "Controller"
        guard let pad = controller.extendedGamepad else { return }

        pad.dpad.valueChangedHandler = { [weak self] _, x, y in
            guard let self else { return }
            self.dpad = Dir(x: self.resolve(x, current: self.dpad.x),
                            y: self.resolve(-y, current: self.dpad.y))   // up = -1
            self.refresh()
        }
        pad.leftThumbstick.valueChangedHandler = { [weak self] _, x, y in
            guard let self else { return }
            self.stick = Dir(x: self.resolve(x, current: self.stick.x),
                             y: self.resolve(-y, current: self.stick.y))
            self.refresh()
        }

        func press(_ button: GCControllerButtonInput, _ action: @escaping (ControllerManager) -> Void) {
            button.pressedChangedHandler = { [weak self] _, _, pressed in
                if pressed, NSApp.isActive, let self { action(self) }
            }
        }
        press(pad.buttonA) { $0.onConfirm?() }
        press(pad.buttonB) { $0.onBack?() }
        press(pad.buttonX) { $0.onCover?() }       // Square on PlayStation controllers
        press(pad.buttonY) { $0.onRefresh?() }
        press(pad.buttonMenu) { $0.onSettings?() }
        press(pad.leftShoulder) { $0.onShoulder?(-1) }
        press(pad.rightShoulder) { $0.onShoulder?(1) }
        press(pad.leftTrigger) { $0.onJump?(-1) }
        press(pad.rightTrigger) { $0.onJump?(1) }
    }

    /// Turns an analog value into -1 / 0 / 1. Pressing needs a firm push, letting go needs
    /// the stick to come back near center, so a stick resting around the threshold can't flutter.
    private func resolve(_ v: Float, current: Int) -> Int {
        if current > 0 { return v > 0.35 ? 1 : 0 }
        if current < 0 { return v < -0.35 ? -1 : 0 }
        return v > 0.6 ? 1 : (v < -0.6 ? -1 : 0)
    }

    /// Recomputes the effective direction. Fires once on a new press, then repeats only if held.
    private func refresh() {
        var d = dpad.isNeutral ? stick : dpad
        if d.x != 0 && d.y != 0 {
            // One axis at a time: keep the one already active, otherwise prefer left/right.
            if active.y != 0 && d.y == active.y { d.x = 0 } else { d.y = 0 }
        }
        guard d != active else { return }
        active = d

        if d.isNeutral {
            timer?.invalidate()
            timer = nil
            return
        }

        fire(d)
        nextRepeat = ProcessInfo.processInfo.systemUptime + initialDelay
        if timer == nil {
            let t = Timer(timeInterval: 0.016, repeats: true) { [weak self] _ in self?.tick() }
            RunLoop.main.add(t, forMode: .common)
            timer = t
        }
    }

    private func tick() {
        guard !active.isNeutral else { return }
        // Only left/right repeats; up/down (library switching) is one step per press.
        guard active.y == 0 else { return }
        let now = ProcessInfo.processInfo.systemUptime
        guard now >= nextRepeat else { return }
        nextRepeat = now + repeatInterval
        fire(active)
    }

    private func fire(_ d: Dir) {
        guard NSApp.isActive else { return }
        onMove?(d.x, d.y)
    }
}
