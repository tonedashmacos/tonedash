import Foundation
import SwiftUI
import AppKit
import UniformTypeIdentifiers

/// One-time move of data from the app's old name (ISO Launcher) so libraries and covers carry over.
enum Migration {
    static func run() {
        let fm = FileManager.default
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        let old = base.appendingPathComponent("ISOLauncher")
        let new = base.appendingPathComponent("Tonedash")
        if fm.fileExists(atPath: old.path), !fm.fileExists(atPath: new.path) {
            try? fm.moveItem(at: old, to: new)
        }
        let key = "libraries.v1"
        if UserDefaults.standard.data(forKey: key) == nil,
           let data = UserDefaults.standard.persistentDomain(forName: "com.local.isolauncher")?[key] as? Data {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}

final class LibraryStore: ObservableObject {
    static let allID = UUID(uuidString: "00000000-0000-0000-0000-000000000000")!
    static let gameExtensions: Set<String> = [
        // Discs
        "iso", "cue", "chd", "cso", "ciso", "gcm", "rvz", "wbfs", "img",
        // NES
        "nes", "unf", "unif",
        // SNES
        "sfc", "smc", "fig", "swc",
        // N64
        "z64", "n64", "v64",
        // Game Boy / Color / Advance
        "gb", "gbc", "gba",
        // Genesis / Mega Drive
        "gen", "md", "bin",
        // DS and 3DS
        "nds", "3ds", "cci", "zcci", "cia", "cxi",
        // Switch
        "nsp", "xci",
        // Archives (NES, GB, GBA, DS ROMs are often zipped)
        "zip"
    ]
    /// Extensions that are really just data tracks when a .cue sheet sits in the same folder.
    private static let trackExtensions: Set<String> = ["bin", "img"]

    @Published var libraries: [Library] = [] { didSet { save() } }
    @Published var games: [Game] = []
    @Published var selectedLibraryID: UUID? = LibraryStore.allID { didSet { ensureSelection() } }
    @Published var selectedGameID: String?
    @Published var showSettings = false
    @Published var launchingTitle: String?
    @Published var identifyStatus: String?
    @Published var lastError: String?
    @Published var coverMenuGame: Game?
    @Published var coverMenuIndex = 0
    @Published var pickingCover = false
    @Published var coverRevision = 0
    @Published var backgroundImage: NSImage?

    private let key = "libraries.v1"
    private var cache: [String: CacheEntry] = [:]
    private var stamps: [String: Stamp] = [:]
    private var identifyTask: Task<Void, Never>?

    private static let cacheURL: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Tonedash/identity-cache.json")
    }()

    init() {
        Migration.run()
        load()
        loadBackground()
        loadCache()
        rescan()
    }

    /// Controller and keyboard input is ignored while the settings sheet or file picker is open.
    var paused: Bool { showSettings || pickingCover }

    /// True while normal browsing input should be ignored (including the cover menu being open).
    var inputLocked: Bool { paused || coverMenuGame != nil }

    var visibleGames: [Game] {
        games.filter { g in
            selectedLibraryID == nil || selectedLibraryID == Self.allID || g.library.id == selectedLibraryID
        }
    }

    var selectedIndex: Int {
        visibleGames.firstIndex { $0.id == selectedGameID } ?? 0
    }

    // MARK: Persistence

    private func save() {
        if let data = try? JSONEncoder().encode(libraries) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    private func load() {
        if let data = UserDefaults.standard.data(forKey: key),
           let list = try? JSONDecoder().decode([Library].self, from: data) {
            libraries = list
        }
    }

    private func loadCache() {
        if let data = try? Data(contentsOf: Self.cacheURL),
           let decoded = try? JSONDecoder().decode([String: CacheEntry].self, from: data) {
            cache = decoded
        }
    }

    private func saveCache() {
        let dir = Self.cacheURL.deletingLastPathComponent()
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        if let data = try? JSONEncoder().encode(cache) {
            try? data.write(to: Self.cacheURL)
        }
    }

    // MARK: Scanning

    func rescan() {
        identifyTask?.cancel()

        var result: [Game] = []
        stamps = [:]
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.fileSizeKey, .contentModificationDateKey]

        var cueFolders: [String: Bool] = [:]
        for lib in libraries where !lib.folderPath.isEmpty {
            let root = URL(fileURLWithPath: lib.folderPath)
            guard let walker = fm.enumerator(at: root, includingPropertiesForKeys: keys,
                                             options: [.skipsHiddenFiles, .skipsPackageDescendants]) else { continue }
            for case let file as URL in walker {
                let ext = file.pathExtension.lowercased()
                guard Self.gameExtensions.contains(ext) else { continue }
                // A .bin/.img next to a .cue is a disc track; the .cue is the game.
                if Self.trackExtensions.contains(ext), folderHasCue(file.deletingLastPathComponent(), &cueFolders) { continue }

                let values = try? file.resourceValues(forKeys: Set(keys))
                let stamp = Stamp(size: UInt64(values?.fileSize ?? 0),
                                  mtime: values?.contentModificationDate?.timeIntervalSince1970 ?? 0)
                stamps[file.path] = stamp

                var info: DiscInfo?
                if let entry = cache[file.path], entry.size == stamp.size, entry.mtime == stamp.mtime {
                    info = entry.info
                }
                result.append(Game(id: file.path,
                                   title: file.deletingPathExtension().lastPathComponent,
                                   path: file.path,
                                   library: lib,
                                   info: info))
            }
        }
        games = result.sorted { $0.title.localizedCaseInsensitiveCompare($1.title) == .orderedAscending }
        ensureSelection()
        identifyInBackground()
    }

    private func folderHasCue(_ folder: URL, _ cache: inout [String: Bool]) -> Bool {
        if let known = cache[folder.path] { return known }
        let names = (try? FileManager.default.contentsOfDirectory(atPath: folder.path)) ?? []
        let has = names.contains { $0.lowercased().hasSuffix(".cue") }
        cache[folder.path] = has
        return has
    }

    func ensureSelection() {
        let list = visibleGames
        if !list.contains(where: { $0.id == selectedGameID }) {
            selectedGameID = list.first?.id
        }
    }

    // MARK: Automatic identification

    private func needsIdentify(_ game: Game) -> Bool {
        guard let stamp = stamps[game.path] else { return false }
        guard let entry = cache[game.path], entry.size == stamp.size, entry.mtime == stamp.mtime else { return true }
        if let info = entry.info, !info.nameChecked { return true }
        return false
    }

    /// Reads each game's ID in the background and looks up its official name.
    /// Results are cached per file, so later launches only process new or changed games.
    private func identifyInBackground() {
        let pending = games.filter { needsIdentify($0) }.map { $0.path }
        guard !pending.isEmpty else {
            identifyStatus = nil
            return
        }
        let total = pending.count
        let stampsCopy = stamps
        identifyStatus = "Identifying games… 0/\(total)"

        identifyTask = Task { [weak self] in
            var batch: [String: CacheEntry] = [:]
            var done = 0

            for path in pending {
                if Task.isCancelled { break }

                var info = await Task.detached(priority: .utility) {
                    DiscIdentifier.identify(path: path)
                }.value

                if var found = info, !found.nameChecked {
                    let result = await NameIndex.shared.lookup(id: found.id, system: found.system)
                    found.name = result.name
                    found.nameChecked = result.available
                    info = found
                }

                let stamp = stampsCopy[path] ?? Stamp(size: 0, mtime: 0)
                batch[path] = CacheEntry(size: stamp.size, mtime: stamp.mtime, info: info)
                done += 1

                if batch.count >= 40 || done == total {
                    let chunk = batch
                    let progress = done
                    batch = [:]
                    await MainActor.run { self?.merge(chunk, done: progress, total: total) }
                }
            }

            if !batch.isEmpty {
                let chunk = batch
                let progress = done
                await MainActor.run { self?.merge(chunk, done: progress, total: total) }
            }
            if !Task.isCancelled {
                await MainActor.run { self?.finishIdentify() }
            }
        }
    }

    private func merge(_ batch: [String: CacheEntry], done: Int, total: Int) {
        for (path, entry) in batch { cache[path] = entry }
        games = games.map { game in
            guard let entry = batch[game.path] else { return game }
            var updated = game
            updated.info = entry.info
            return updated
        }
        identifyStatus = done >= total ? nil : "Identifying games… \(done)/\(total)"
    }

    private func finishIdentify() {
        identifyStatus = nil
        saveCache()
    }

    // MARK: Navigation (controller, keyboard, mouse)

    /// Moves the selection left or right through the carousel. Stops at both ends.
    func move(dx: Int, dy: Int = 0) {
        let list = visibleGames
        guard !list.isEmpty else { return }
        let next = min(max(selectedIndex + dx, 0), list.count - 1)
        selectedGameID = list[next].id
    }

    func cycleLibrary(_ step: Int) {
        let ids = [Self.allID] + libraries.map(\.id)
        let current = ids.firstIndex(of: selectedLibraryID ?? Self.allID) ?? 0
        selectedLibraryID = ids[(current + step + ids.count) % ids.count]
    }

    // MARK: Cover menu

    enum CoverOption {
        case add, remove, cancel
        var title: String {
            switch self {
            case .add: return "Add Game Cover…"
            case .remove: return "Remove Custom Cover"
            case .cancel: return "Cancel"
            }
        }
    }

    var coverMenuOptions: [CoverOption] {
        guard let game = coverMenuGame else { return [] }
        return CoverLoader.hasCustom(game) ? [.add, .remove, .cancel] : [.add, .cancel]
    }

    func openCoverMenu() {
        guard !paused, coverMenuGame == nil else { return }
        let list = visibleGames
        guard !list.isEmpty else { return }
        coverMenuGame = list[min(selectedIndex, list.count - 1)]
        coverMenuIndex = 0
    }

    func closeCoverMenu() { coverMenuGame = nil }

    func moveCoverMenu(_ step: Int) {
        let count = coverMenuOptions.count
        guard count > 0 else { return }
        coverMenuIndex = min(max(coverMenuIndex + step, 0), count - 1)
    }

    func activateCoverMenu() {
        let options = coverMenuOptions
        guard coverMenuIndex < options.count else { return }
        chooseCoverOption(options[coverMenuIndex])
    }

    func chooseCoverOption(_ option: CoverOption) {
        guard let game = coverMenuGame else { return }
        coverMenuGame = nil
        switch option {
        case .add: pickCover(for: game)
        case .remove:
            CoverLoader.removeCustom(for: game)
            coverRevision += 1
        case .cancel: break
        }
    }

    private func pickCover(for game: Game) {
        let panel = NSOpenPanel()
        panel.title = "Choose a cover for \(game.displayTitle)"
        panel.message = "Pick a PNG or JPG image."
        panel.prompt = "Use as Cover"
        panel.allowedContentTypes = [.png, .jpeg]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.directoryURL = FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask).first

        pickingCover = true
        let handle: (NSApplication.ModalResponse) -> Void = { [weak self] response in
            guard let self else { return }
            self.pickingCover = false
            guard response == .OK, let url = panel.url else { return }
            do {
                try CoverLoader.setCustom(from: url, for: game)
                self.coverRevision += 1
            } catch {
                self.lastError = "Couldn't set cover: \(error.localizedDescription)"
            }
        }
        // A sheet on the main window works reliably while the app is fullscreen.
        if let window = NSApp.keyWindow ?? NSApp.windows.first(where: { $0.isVisible }) {
            panel.beginSheetModal(for: window, completionHandler: handle)
        } else {
            panel.begin(completionHandler: handle)
        }
    }

    // MARK: Dashboard background

    private static let backgroundDir: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Tonedash", isDirectory: true)
    }()

    private static func existingBackgroundFiles() -> [URL] {
        let files = (try? FileManager.default.contentsOfDirectory(at: backgroundDir, includingPropertiesForKeys: nil)) ?? []
        return files.filter { $0.deletingPathExtension().lastPathComponent == "background" }
    }

    private func loadBackground() {
        if let url = Self.existingBackgroundFiles().first,
           let data = try? Data(contentsOf: url) {
            backgroundImage = NSImage(data: data)
        }
    }

    /// Opens Finder to pick any image and uses it as the dashboard background.
    func chooseBackground() {
        let panel = NSOpenPanel()
        panel.title = "Choose a dashboard background"
        panel.message = "Pick any image."
        panel.prompt = "Use as Background"
        panel.allowedContentTypes = [.image]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.directoryURL = FileManager.default.urls(for: .picturesDirectory, in: .userDomainMask).first
        guard panel.runModal() == .OK, let url = panel.url else { return }
        do {
            let data = try Data(contentsOf: url)
            guard let image = NSImage(data: data) else {
                lastError = "That file isn't a readable image."
                return
            }
            try FileManager.default.createDirectory(at: Self.backgroundDir, withIntermediateDirectories: true)
            Self.existingBackgroundFiles().forEach { try? FileManager.default.removeItem(at: $0) }
            let ext = url.pathExtension.isEmpty ? "img" : url.pathExtension.lowercased()
            try data.write(to: Self.backgroundDir.appendingPathComponent("background.\(ext)"))
            backgroundImage = image
        } catch {
            lastError = "Couldn't set background: \(error.localizedDescription)"
        }
    }

    func resetBackground() {
        Self.existingBackgroundFiles().forEach { try? FileManager.default.removeItem(at: $0) }
        backgroundImage = nil
    }

    // MARK: Launching

    func launchSelected() {
        let list = visibleGames
        guard !list.isEmpty else { return }
        launch(list[min(selectedIndex, list.count - 1)])
    }

    /// Tonedash leaves its own fullscreen Space before starting an emulator, so the emulator can
    /// open (and go fullscreen) normally, then returns to fullscreen when the emulator quits.
    func launch(_ game: Game) {
        let lib = game.library
        guard !lib.emulatorPath.isEmpty else {
            lastError = "No emulator is set for \"\(lib.name)\". Open Libraries and choose one."
            return
        }
        guard launchingTitle == nil else { return }
        let title = game.displayTitle
        launchingTitle = title

        leaveFullscreen { [weak self] wasFullscreen in
            self?.start(game, restoreFullscreen: wasFullscreen)
        }
    }

    private func leaveFullscreen(_ completion: @escaping (Bool) -> Void) {
        guard let window = NSApp.windows.first(where: { $0.styleMask.contains(.fullScreen) }) else {
            completion(false)
            return
        }
        var finished = false
        var token: NSObjectProtocol?
        let finish = {
            guard !finished else { return }
            finished = true
            if let token { NotificationCenter.default.removeObserver(token) }
            // Let the exit animation settle before the emulator starts.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { completion(true) }
        }
        token = NotificationCenter.default.addObserver(forName: NSWindow.didExitFullScreenNotification,
                                                       object: window, queue: .main) { _ in finish() }
        window.toggleFullScreen(nil)
        // Safety net in case the notification never arrives.
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { finish() }
    }

    /// Set when Tonedash left fullscreen for a game and should go back once it's over.
    private var restorePending = false

    /// Called when the emulator has quit: give its own fullscreen animation a moment to finish, then come back.
    private func emulatorQuit() {
        guard restorePending else { return }
        NSApp.activate(ignoringOtherApps: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in
            self?.restoreFullscreenNow(retry: true)
        }
    }

    private func restoreFullscreenNow(retry: Bool) {
        guard restorePending else { return }
        NSApp.activate(ignoringOtherApps: true)
        guard let window = NSApp.windows.first(where: { $0.canBecomeMain }) else { return }
        if window.isMiniaturized { window.deminiaturize(nil) }
        window.makeKeyAndOrderFront(nil)
        if window.styleMask.contains(.fullScreen) {
            restorePending = false
            return
        }
        window.toggleFullScreen(nil)
        // If a Space transition swallowed the first attempt, try once more.
        if retry {
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
                guard let self, self.restorePending else { return }
                self.restoreFullscreenNow(retry: false)
            }
        } else {
            restorePending = false
        }
    }

    private func start(_ game: Game, restoreFullscreen: Bool) {
        let lib = game.library
        let args = lib.extraArgs.split(separator: " ").map(String.init) + [game.path]
        let title = game.displayTitle

        restorePending = restoreFullscreen

        let failed: (String) -> Void = { [weak self] message in
            guard let self else { return }
            self.launchingTitle = nil
            self.lastError = message
            self.restoreFullscreenNow(retry: true)
        }
        let started: () -> Void = { [weak self] in
            DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
                if self?.launchingTitle == title { self?.launchingTitle = nil }
            }
        }

        if lib.emulatorPath.hasSuffix(".app") {
            let config = NSWorkspace.OpenConfiguration()
            config.arguments = args
            config.createsNewApplicationInstance = true
            config.activates = true
            NSWorkspace.shared.openApplication(at: URL(fileURLWithPath: lib.emulatorPath),
                                               configuration: config) { [weak self] app, error in
                DispatchQueue.main.async {
                    if let error {
                        failed("Couldn't launch: \(error.localizedDescription)")
                        return
                    }
                    started()
                    guard restoreFullscreen, let app else { return }
                    let pid = app.processIdentifier
                    let bundleID = app.bundleIdentifier
                    var token: NSObjectProtocol?
                    token = NSWorkspace.shared.notificationCenter.addObserver(
                        forName: NSWorkspace.didTerminateApplicationNotification,
                        object: nil, queue: .main) { note in
                        let ended = note.userInfo?[NSWorkspace.applicationUserInfoKey] as? NSRunningApplication
                        // Match the exact process, or the same emulator app once no copy of it is left
                        // (some emulators hand off to a second process and the first one exits early).
                        let sameProcess = ended?.processIdentifier == pid
                        let sameApp = bundleID != nil && ended?.bundleIdentifier == bundleID
                            && NSRunningApplication.runningApplications(withBundleIdentifier: bundleID!)
                                .filter { $0.processIdentifier != ended?.processIdentifier }.isEmpty
                        guard sameProcess || sameApp else { return }
                        if let token { NSWorkspace.shared.notificationCenter.removeObserver(token) }
                        self?.emulatorQuit()
                    }
                }
            }
        } else {
            let process = Process()
            process.executableURL = URL(fileURLWithPath: lib.emulatorPath)
            process.arguments = args
            if restoreFullscreen {
                process.terminationHandler = { [weak self] _ in
                    DispatchQueue.main.async { self?.emulatorQuit() }
                }
            }
            do {
                try process.run()
                started()
            } catch {
                failed("Couldn't launch: \(error.localizedDescription)")
            }
        }
    }
}
