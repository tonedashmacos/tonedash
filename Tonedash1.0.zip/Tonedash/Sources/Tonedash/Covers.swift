import Foundation
import AppKit
import CryptoKit

/// Remembers covers that couldn't be found so scrolling doesn't re-request them.
actor CoverMisses {
    static let shared = CoverMisses()
    private var keys: Set<String> = []
    func has(_ key: String) -> Bool { keys.contains(key) }
    func add(_ key: String) { keys.insert(key) }
}

enum CoverLoader {
    static let cacheDir: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Tonedash/covers", isDirectory: true)
    }()

    private static func safe(_ s: String) -> String {
        var out = s
        for ch in ["&", "*", "/", ":", "`", "<", ">", "?", "\\", "|", "\""] {
            out = out.replacingOccurrences(of: ch, with: "_")
        }
        return out
    }

    // MARK: Custom covers (picked by the user)

    static let customDir: URL = {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        return base.appendingPathComponent("Tonedash/custom-covers", isDirectory: true)
    }()

    private static func customBase(for game: Game) -> URL {
        let hash = SHA256.hash(data: Data(game.path.utf8)).map { String(format: "%02x", $0) }.joined()
        return customDir.appendingPathComponent(hash)
    }

    static func customCoverURL(for game: Game) -> URL? {
        let base = customBase(for: game)
        for ext in ["png", "jpg"] {
            let url = base.appendingPathExtension(ext)
            if FileManager.default.fileExists(atPath: url.path) { return url }
        }
        return nil
    }

    static func hasCustom(_ game: Game) -> Bool { customCoverURL(for: game) != nil }

    /// Copies the chosen image into the app's own folder so it survives the original being moved.
    static func setCustom(from source: URL, for game: Game) throws {
        let data = try Data(contentsOf: source)
        guard NSImage(data: data) != nil else {
            throw NSError(domain: "Tonedash", code: 1,
                          userInfo: [NSLocalizedDescriptionKey: "That file isn't a readable image."])
        }
        let isPNG = data.starts(with: [0x89, 0x50, 0x4E, 0x47])
        try FileManager.default.createDirectory(at: customDir, withIntermediateDirectories: true)
        removeCustom(for: game)
        try data.write(to: customBase(for: game).appendingPathExtension(isPNG ? "png" : "jpg"))
    }

    static func removeCustom(for game: Game) {
        if let url = customCoverURL(for: game) { try? FileManager.default.removeItem(at: url) }
    }

    static func load(for game: Game) async -> NSImage? {
        // 0. A cover picked in the app wins over everything.
        if let url = customCoverURL(for: game),
           let data = try? Data(contentsOf: url),
           let img = NSImage(data: data) { return img }

        // 1. A picture next to the game file with the same name always wins.
        let base = URL(fileURLWithPath: game.path).deletingPathExtension()
        for ext in ["png", "jpg", "jpeg"] {
            if let img = NSImage(contentsOf: base.appendingPathExtension(ext)) { return img }
        }

        // 2. Cached download. Keyed by game ID when we have one, otherwise by file name.
        let system = game.info?.system ?? game.library.libretroSystem
        let key = game.info?.id ?? game.title
        let folder = system.isEmpty ? "Unsorted" : system
        let cacheFile = cacheDir
            .appendingPathComponent(safe(folder), isDirectory: true)
            .appendingPathComponent(safe(key) + ".png")
        if let img = NSImage(contentsOf: cacheFile) { return img }

        let missKey = folder + "/" + key
        if await CoverMisses.shared.has(missKey) { return nil }

        // 3. Candidate download locations, best first.
        var urls: [URL] = []
        if let info = game.info, info.system.hasPrefix("Nintendo") {
            urls += gameTDBURLs(id: info.id)
        }
        if !system.isEmpty {
            var names: [String] = []
            for candidate in [game.info?.name, game.info?.title, game.title] {
                if let candidate, !candidate.isEmpty, !names.contains(candidate) { names.append(candidate) }
            }
            urls += names.compactMap { libretroURL(system: system, name: $0) }
        }

        for url in urls {
            if let data = await fetch(url), let img = NSImage(data: data) {
                try? FileManager.default.createDirectory(at: cacheFile.deletingLastPathComponent(),
                                                         withIntermediateDirectories: true)
                try? data.write(to: cacheFile)
                return img
            }
        }
        await CoverMisses.shared.add(missKey)
        return nil
    }

    private static func libretroURL(system: String, name: String) -> URL? {
        let allowed = CharacterSet.urlPathAllowed
        guard let sys = safe(system).addingPercentEncoding(withAllowedCharacters: allowed),
              let file = safe(name).addingPercentEncoding(withAllowedCharacters: allowed) else { return nil }
        return URL(string: "https://thumbnails.libretro.com/\(sys)/Named_Boxarts/\(file).png")
    }

    /// GameTDB hosts GameCube and Wii covers by 6-character ID and region folder.
    private static func gameTDBURLs(id: String) -> [URL] {
        guard id.count == 6 else { return [] }
        let regionChar = id[id.index(id.startIndex, offsetBy: 3)]
        let primary: String
        switch regionChar {
        case "E": primary = "US"
        case "J": primary = "JA"
        case "K": primary = "KO"
        case "D": primary = "DE"
        case "F": primary = "FR"
        case "I": primary = "IT"
        case "S": primary = "ES"
        case "H": primary = "NL"
        case "R": primary = "RU"
        case "U": primary = "AU"
        default: primary = "EN"
        }
        var regions = [primary]
        for r in ["EN", "US", "JA"] where !regions.contains(r) { regions.append(r) }
        return regions.compactMap { URL(string: "https://art.gametdb.com/wii/cover/\($0)/\(id).png") }
    }

    private static func fetch(_ url: URL) async -> Data? {
        var request = URLRequest(url: url)
        request.timeoutInterval = 15
        guard let (data, response) = try? await URLSession.shared.data(for: request),
              (response as? HTTPURLResponse)?.statusCode == 200,
              data.count > 500 else { return nil }
        return data
    }
}
