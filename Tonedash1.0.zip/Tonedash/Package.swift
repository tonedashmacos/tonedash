// swift-tools-version:5.9
import PackageDescription

let package = Package(
    name: "Tonedash",
    platforms: [.macOS(.v13)],
    targets: [
        .executableTarget(name: "Tonedash", path: "Sources/Tonedash")
    ]
)
