#!/bin/bash
# Builds Tonedash.app (requires Xcode or Xcode Command Line Tools: xcode-select --install)
set -e
cd "$(dirname "$0")"

swift build -c release

APP="Tonedash.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"
cp .build/release/Tonedash "$APP/Contents/MacOS/Tonedash"
cp Info.plist "$APP/Contents/Info.plist"
codesign --force --deep --sign - "$APP" 2>/dev/null || true

echo "Built $(pwd)/$APP"
open .
