# Tonedash

A small SwiftUI Mac app: a cover-art grid of your game files, launched through the emulator you pick, fully usable with a gamepad.

## Build
Needs Xcode or the command line tools (`xcode-select --install`).

    chmod +x build.sh
    ./build.sh

This produces `Tonedash.app`. If macOS blocks it the first time, right-click it and choose Open.

## Setup
1. Click the gear (Libraries), then Add Library and pick a preset (or Custom).
2. Choose the games folder and the emulator app. Edit the arguments if your emulator needs different ones.
3. Done. Games appear with covers.

## Automatic identification
On every rescan the app reads each game's ID straight from the file (GameCube/Wii header, PS1/PS2 `SYSTEM.CNF`, PSP `PARAM.SFO`), looks up the official name in libretro's database, and downloads the cover. Results are cached, so only new or changed files are processed next time. Mixed folders work. `.chd`, `.cso` and `.rvz` aren't read yet and fall back to the file name.

## Covers
- Highlight a game and press X (Square) on the controller, or C on the keyboard, to open the cover menu and pick a PNG or JPG from Finder. These are copied into `~/Library/Application Support/Tonedash/custom-covers` and always win. You can remove one from the same menu.
- A `.png` or `.jpg` with the same name as the game file, in the same folder, is always used first.
- Otherwise box art is downloaded from the libretro thumbnail server using the file name, so names like `Game Name (USA)` match best. Downloads are cached in `~/Library/Application Support/Tonedash/covers`.

## Controls
- Controller: left/right (D-pad or stick) browse, up/down or LB/RB switch library, LT/RT jump 10 games, A play, X (Square) cover menu, B back, Y rescan, Menu opens Libraries
- Keyboard: arrows browse and switch library, Return play, S libraries, C cover menu, R rescan, F toggle fullscreen
- Mouse: click a cover to select it, click the selected one to play

## Supported file types
Discs (`.iso .cue .chd .cso .ciso .gcm .rvz .wbfs .img`), NES (`.nes .unf .unif`), SNES (`.sfc .smc .fig .swc`), N64 (`.z64 .n64 .v64`), Game Boy / Color / Advance (`.gb .gbc .gba`), Genesis (`.gen .md .bin`), DS and 3DS (`.nds .3ds .cci .zcci .cia .cxi`), Switch (`.nsp .xci`) and `.zip`. A `.bin` or `.img` next to a `.cue` is treated as part of that disc, not a separate game. Cartridge ROMs aren't read for IDs, so they use the file name; set the library's "Fallback cover system" (the presets do this) so covers can still download.
